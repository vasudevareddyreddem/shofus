<?php
defined('BASEPATH') OR exit('No direct script access allowed');
@include_once( APPPATH . 'controllers/seller_admin/Admin_Controller.php');


class Dashboard extends Admin_Controller {

	
	public function __construct() {
		parent::__construct();
		$this->load->model('seller_admin/dashboard_model');
		
		
	}

	public function index()
	{
		
		//$this->load->view('welcome_message');
		//echo "ddg"; exit;
		$data['sellersubcatdata'] = $this->dashboard_model->getsellersubcatdata();
		
		//print_r($data['sellersubcatdata']); exit;
		$this->template->write_view('content', 'seller_admin/dashboard/index', $data);
		$this->template->render();


	}
	public function subcategoryview()
	{
		$cat_id = $this->uri->segment(4);
		$data['sellerdata'] = $this->dashboard_model->getsellerdata($cat_id);
		//$this->load->view('welcome_message');
		//echo "ddg"; exit;
		//$data['sellersubcatdata'] = $this->dashboard_model->getsellersubcatdata();
		
	//print_r($data['sellerdata']); exit;
		$this->template->write_view('content', 'seller_admin/dashboard/subcategory_view', $data);
		$this->template->render();


	}
	
	
	
}