 <!--main content start-->
  <section id="main-content">
    <section class="wrapper">
      <div class="row">
        <div class="col-lg-12">
		<div class="row">
		 <div class="col-md-7">
          <h3 class="page-header"><i class="fa fa-cutlery" aria-hidden="true"></i>Add <?php echo $catname->category_name;?> Item Details</h3></div>
		   <div class="col-md-5 pull-right">
         <form class="navbar-form" action="<?php echo base_url(); ?>seller_admin/products/<?php echo $this->uri->segment('3');?>/<?php echo $this->uri->segment('4');?>/search" method="post">
          <input class="form-control" placeholder="Search" name="search" type="text">
         <button class="btn btn-default" type="submit">Go!</button>
          </form>
            </div>
		  </div>
          <ol class="breadcrumb">
            <li><i class="fa fa-home"></i><a href="<?php echo base_url();?>">Home</a></li>
            <li><i class="fa fa-cutlery" aria-hidden="true"></i><?php echo $catname->category_name;?></li>
            <li><i class="fa fa-square-o"></i><?php echo $subcatname->subcategory_name;?></li>
          </ol>
        </div>
		
      </div>
      <div class="row">
        <div class="col-md-12">
          <section class="panel">
            <header class="panel-heading">
              <h3><?php echo $subcatname->subcategory_name;?></h3>
            </header>
			 <div><?php echo $this->session->flashdata('message');?></div>
            <div class="panel-body"> <a href="<?php echo base_url();  ?>seller_admin/products/create/<?php echo $this->uri->segment('3'); ?>/<?php echo $this->uri->segment('4'); ?>" class="add_item">
              <button class="btn btn-primary" type="submit">Add Items</button>
              </a>
              <div class="table-responsive">
                <table class="table table-bordered table-striped">
                  <thead>
                    <tr>
                      <th>S.No</th>
                      <th>Item Name</th>
                      <th>Item Code</th>
                      <th>Description</th>
                      <th>Quantity</th>
                      <th>Item Cost</th>
                      <th>Image</th>
                      <th>Status</th>
                      <th>Edit</th>
                      <th>Delete</th>
                    </tr>
                  </thead>
                  <tbody>
				  <?php $k=1; 
				  foreach($itemdata as $item_data){?>
                    <tr>
                      <td><?= $k; ?></td>
                      <td><?php echo $item_data->item_name;?></td>
                      <td><?php echo $item_data->item_code;?></td>
                      <td><?php echo $item_data->item_description;?></td>
                      <td><?php echo $item_data->item_quantity;?></td>
                      <td><?php echo $item_data->item_cost;?></td>
					  <?php if($item_data->item_image == "") {  ?>
					  
					  <td><img src="<?php echo base_url(); ?>assets/seller_admin/img/avatar1.jpg" class="img-responsive"></td>
					  <?php } else {?>
                      <td><img src="<?php echo base_url();?>uploads/products/<?php  echo $item_data->item_image; ?>" width="80" height="50" /></td>
					  <?php } ?>
					 <!--<td><img src="img/avatar1.jpg" class="img-responsive"></td>-->
					 <?php if($item_data->item_status == 1) {  ?>
                      <td>Available</td>
					 <?php } else {?>
					 
					 <td>Unavailable</td>
					 <?php } ?>
                      <td><a href="<?php echo site_url(); ?>seller_admin/products/edit/<?php  echo $item_data->item_id; ?>/<?php echo $this->uri->segment('3'); ?>/<?php echo $this->uri->segment('4'); ?>"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a></td>
                      <td><a href="<?php echo site_url(); ?>seller_admin/products/delete/<?php  echo $item_data->item_id; ?>/<?php echo $this->uri->segment('3'); ?>/<?php echo $this->uri->segment('4'); ?>"><i class="fa fa-trash-o" aria-hidden="true"></i></a></td>
                    </tr>
				  <?php $k++; } ?>
                  </tbody>
                </table>
              </div>
            </div>
          </section>
		 
        </div>
      </div>
      <!-- page start--> 
      <!-- page end--> 
    </section>
  </section>
  <!--main content end--> 