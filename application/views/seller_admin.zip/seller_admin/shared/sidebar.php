<!--sidebar start-->
  <aside>
    <div id="sidebar"  class="nav-collapse "> 
      <!-- sidebar menu start-->
      <ul class="sidebar-menu">
        <li class="active"> <a class="" href="<?php echo base_url(); ?>seller_admin/dashboard"> <i class="icon_house_alt"></i> <span>Home</span> </a> </li>
		<li class=""> <a class="" href="<?php echo base_url(); ?>seller_admin/subcategory"> <i class="fa fa-cutlery"></i> <span>Add Subcategories</span> </a> </li>
		<?php foreach($catdata as $cat_data){?>
        <li class="sub-menu"> <a href="javascript:;" class=""> <i class="fa fa-cutlery" aria-hidden="true"></i> <span><?php echo $cat_data->category_name;  ?></span> <span class="menu-arrow arrow_carrot-right"></span> </a>
          <ul class="sub">
		  <?php foreach($cat_data->subcat as $subcat){?>
            <li><a class="" href="<?php echo base_url(); ?>seller_admin/products/<?php echo $cat_data->category_id;  ?>/<?php echo $subcat->subcategory_id;  ?>"><?php echo $subcat->subcategory_name;  ?> </a></li>
		  <?php } ?>
          </ul>
        </li>
        <?php } ?>

          <li class="sub-menu"> <a href="javascript:;" class=""> <i class="fa fa-list-ol" aria-hidden="true"></i> <span>Orders</span> <span class="menu-arrow arrow_carrot-right"></span> </a>
          <ul class="sub">
            <li><a class="" href="<?php echo base_url();?>seller_admin/orders/new_orders">New Orders</a></li>
            <li><a class="" href="<?php echo base_url();?>seller_admin/orders/assigned_orders">Assigned Orders</a></li>
            <li><a class="" href="<?php echo base_url();?>seller_admin/orders/inprogress_orders">In-progress Orders</a></li>
            <li><a class="" href="<?php echo base_url();?>seller_admin/orders/delivered_orders">Delivered Orders</a></li>  

            <li><a class="" href="<?php echo base_url();?>seller_admin/orders/rejected_orders">Rejected Orders</a></li>        
          </ul>
        </li>
        
        <li> <a class="" href="<?php echo base_url();?>seller_admin/payments"> <i class="fa fa-list-ol"></i> <span>Payment History</span> </a> </li>
		
		<li> <a class="" href="<?php echo base_url();?>seller_admin/pricing"> <i class="fa fa-list-ol"></i> <span>Pricing Calculation</span> </a> </li>
       <!-- <li class="sub-menu"> <a href="javascript:;" class=""> <i class="icon_documents_alt"></i> <span>Categerious</span> <span class="menu-arrow arrow_carrot-right"></span> </a>
          <ul class="sub">
            <li><a class="" href="#">Profile</a></li>
            <li><a class="" href="#"><span>Login Page</span></a></li>
          </ul>
        </li>
        <li> <a class="" href="#"> <i class="icon_genius"></i> <span>Others</span> </a> </li>-->
      </ul>
      <!-- sidebar menu end--> 
    </div>
  </aside>
  <!--sidebar end--> 