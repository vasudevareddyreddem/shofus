<!--footer part start here -->
  <footer class="footer">
    <div class="container">
      <div class="row">
        <div class="col-md-4">
          <div class="ftr">
            <div class="queries">Download our seller apps from here</div>
            <a href="#" class="googleApp" target="_blank"><img src="<?php echo base_url();  ?>assets/seller_admin/images/google.png" class="img-responsive" /></a> <a href="#" class="googleApp" target="_blank"><img src="<?php echo base_url();  ?>assets/seller_admin/images/play.png" class="img-responsive" /></a> </div>
        </div>
        <div class="col-md-2"> &nbsp;</div>
        <div class="col-md-2">
          <div class="siteMap">
            <p>Site Map</p>
            <ul>
              <li><a href="#">Home</a></li>
              <li><a href="#">Cart in Hour </a></li>
              <li><a href="#">Resources</a></li>
              <li><a href="#">Seller Diaries</a></li>
              <li><a href="#">FAQs</a></li>
            </ul>
          </div>
        </div>
        <div class="col-md-4">
          <div class="siteMap">
            <p>Social</p>
            <ul class="social-network social-circle">
              <li><a href="#" class="icoRss" title="Rss"><i class="fa fa-rss"></i></a></li>
              <li><a href="#" class="icoFacebook" title="Facebook"><i class="fa fa-facebook"></i></a></li>
              <li><a href="#" class="icoTwitter" title="Twitter"><i class="fa fa-twitter"></i></a></li>
              <li><a href="#" class="icoGoogle" title="Google +"><i class="fa fa-google-plus"></i></a></li>
              <li><a href="#" class="icoLinkedin" title="Linkedin"><i class="fa fa-linkedin"></i></a></li>
            </ul>
            <!-- <a class="social" href="#" target="_blank"><img src="images/fb.png"></a> <a class="social" href="#" target="_blank"><img src="images/twit.png"></a> <a class="social" href="" target="_blank"><img src="images/lin.png"></a> <a class="social" href="" target="_blank"><img src="images/googlePlus.png"></a> <a class="social" href="" target="_blank"><img src="images/youtube.png"></a> --></div>
        </div>
      </div>
    </div>
  </footer>
  
  <!--footer part end here -->
  <div class="fter">
    <div class="container">
      <div class="row">
        <div class="col-md-12">&copy; <span class="year">2017</span> Cart In Hour. All rights reserved.</div>
      </div>
    </div>
  </div>
  
  <script>
    $(function () {
  $('[data-tooltip="tooltip"]').tooltip()
	});
</script> 